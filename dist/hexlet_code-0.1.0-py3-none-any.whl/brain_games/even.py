print ('huy')
def even():
    print("Answer \"yes\" if the number is even, otherwise answer \"no\".")

