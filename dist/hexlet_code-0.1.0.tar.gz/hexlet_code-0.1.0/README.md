### Description and installing
Project includes several games:
1. Finding prime number
2. Greatest common divisor
3. Simple calculator
4. Test for finding even number
5. Prorgression
Instal project using by GitHub:https://github.com/LAMENTIN28/python-project-49
Use comand clone

#Requirements
Project use python and poetry latest versions

### Hexlet tests and linter status:
[![Actions Status](https://github.com/LAMENTIN28/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LAMENTIN28/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/6a6141c2880c9a007180/maintainability)](https://codeclimate.com/github/LAMENTIN28/file/maintainability)
### Asciinema
https://asciinema.org/connect/e1458e7f-b29a-494b-9377-b67ec6b92a1a
