### Hexlet tests and linter status:
[![Actions Status](https://github.com/LAMENTIN28/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LAMENTIN28/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/6a6141c2880c9a007180/maintainability)](https://codeclimate.com/github/LAMENTIN28/file/maintainability)
